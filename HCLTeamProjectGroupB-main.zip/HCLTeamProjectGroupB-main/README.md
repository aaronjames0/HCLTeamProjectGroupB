# HCLTeamProjectGroupB
Group B: Aaron James, Akhil Nagarajan, Haree Akkala, Joel Sanchez

destinationservice - Aaron James
Recommend-microservice - Akhil Nagarajan
Review-Service - Joel Sanchez (Haree Akkala, Omar Abdel)?
user-service - Joel Sanchez

to-do: Composite-Service - Aaron and Akhil